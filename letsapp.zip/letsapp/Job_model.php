<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Job_model extends MY_WsModel
{
    function __construct()

    {

        $this->load->model('ws/User_model_v1', 'User_model');

    }


    public function get_category()

    {

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');

        $skills = $this->input->post('skills');


        $this->db->select('c.id,c.name,c.image,c.job_count')->from('tbl_category c')->where('c.status', 'active');
        $this->db->where('c.parent_id', 0);

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->order_by('c.id', 'desc')->get()->result_array();

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                $data[$key]['image'] = checkImage(3, $value['image'], 0, 0, false);

                $data[$key]['skills'] = [];

                if (!empty($skills)) {

                    $data[$key]['skills'] = $this->common->get_data_by_id('tbl_skills', 'status', 'active', 'id,name', array('category_id' => $value['id']));

                }

            }

        }


        return $data;

    }

    public function getSubCategory($post = array())
    {

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');

        // $skills = $this->input->post('skills');


        $this->db->where('c.parent_id', $post['category_id']);
        $this->db->select('c.id,c.name,c.price,c.image')->from('tbl_category c')->where('c.status', 'active');

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->order_by('c.id', 'desc')->get()->result_array();

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                $data[$key]['image'] = checkImage(3, $value['image'], 0, 0, false);

                $data[$key]['skills'] = [];

                if (!empty($skills)) {

                    $data[$key]['skills'] = $this->common->get_data_by_id('tbl_skills', 'status', 'active', 'id,name', array('category_id' => $value['id']));

                }

            }

        }


        return $data;

    }


    public function get_city()

    {

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');

        $this->db->select('c.*')->from('tbl_city c')->where('c.status', 'active');

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->order_by('c.id', 'desc')->get()->result_array();

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                $data[$key]['image'] = checkImage(4, $value['image'], 0, 0, false);

            }

        }


        return $data;

    }


    public function get_insert_array($rules = array(), $user_id = 0)

    {

        $data = array(
            'user_id' => $user_id,
            'client_fee' => CLIENT_FEE,
            'freelancer_fee' => FREELANCER_FEE,
            'created' => get_date(),
            'updated' => get_date(),
        );

        foreach ($rules as $key => $value) {

            $data[$value['field']] = $this->input->post($value['field']);

        }

        if (isset($data['task_time'])) {

            $data['task_time'] = date('H:i:s', strtotime($data['task_time']));

        }

        if (isset($data['task_date'])) {

            $data['task_date'] = date('Y-m-d', strtotime($data['task_date']));

        }

        return $data;

    }


    public function job_listing($user_id = 0)

    {

        $where = array(

            'j.user_id!=' => $user_id,

            'j.status' => 'active',

            'u.status' => 'active'

        );

        $search = $this->input->post('search');

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');

        $_lng = !empty($this->input->post('longitude')) ? $this->input->post('longitude') : 0;

        $_lat = !empty($this->input->post('latitude')) ? $this->input->post('latitude') : 0;

        $start_distance = $this->input->post('start_distance');

        $end_distance = $this->input->post('end_distance');

        $start_price = $this->input->post('start_price');

        $end_price = $this->input->post('end_price');

        $category = $this->input->post('category');

        $city = $this->input->post('city');
        $sub_category = $this->input->post('sub_category');

        if ($start_price !== "") {

            $where['j.offer>='] = $start_price;

        }

        if ($end_price !== "") {

            $where['j.offer<='] = $end_price;

        }

        $this->db->select("u.name,u.profile_image,j.*,

        (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE tbl_job_fav.user_id=$user_id AND tbl_job_fav.job_id=j.id) as favourite,

        (SELECT COUNT(tbl_job_ignore.id) FROM tbl_job_ignore WHERE tbl_job_ignore.user_id=$user_id AND tbl_job_ignore.job_id=j.id) as job_ignore,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id AND tbl_job_apply.job_id=j.id) as apply,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.job_id=j.id) as total_apply,

        (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=$user_id AND tbl_threads.iFriendId=j.user_id) OR (tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=$user_id))) as thread_id,

        (111.111 * DEGREES(ACOS(COS(RADIANS(j.start_latitude))

                * COS(RADIANS('$_lat'))

                * COS(RADIANS(j.start_longitude - '$_lng'))

                + SIN(RADIANS(j.start_latitude))

                * SIN(RADIANS('$_lat'))))

                ) AS distance,sc.name as sub_category_name")->from('tbl_job j')->join('tbl_users u', 'u.id=j.user_id')->join('tbl_category sc', 'sc.id=j.sub_category_id', 'left')->where($where)->having('apply', 0)->having('job_ignore', 0);

        if (!empty($city)) {

            $this->db->group_start()->where('start_city', $city)->or_where('end_city', $city)->group_end();

        }

        if (!empty($category)) {

            $this->db->where_in('j.category_id', explode(',', $category));

        }
        if (!empty($sub_category)) {

            $this->db->where_in('j.sub_category_id', explode(',', $sub_category));
        }

        if (!empty($search)) {

            $this->db->group_start()
                ->like('j.start_city', $search)
                ->or_like('j.start_country', $search)
                ->or_like('j.start_location', $search)
                ->or_like('j.end_location', $search)
                ->or_like('j.end_city', $search)
                ->or_like('j.end_country', $search)
                ->or_like('j.description', $search)
                ->or_like('j.qualification', $search)
                ->or_like('j.skills', $search)
                ->or_like('j.type', $search)
                ->group_end();

        }

        if ($start_distance !== "" && $end_distance !== "") {

            $this->db->having('distance>=', $start_distance)->having('distance<=', $end_distance);

        }

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->order_by('j.id', 'DESC')->get()->result_array();

        // $data = $this->db->order_by('distance', 'ASC')->get()->result_array();

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                if (is_null($value['thread_id'])) {

                    $data[$key]['thread_id'] = '0';

                }
                if (is_null($value['sub_category_name'])) {
                    $data[$key]['sub_category_name'] = "";
                }

                $data[$key]['profile_image'] = checkImage(1, $value['profile_image'], 0, 0, false);

            }

        }

        return $data;

    }


    public function job_listing_count($user_id = 0)

    {

        $search = $this->input->post('search');

        $start_distance = $this->input->post('start_distance');

        $end_distance = $this->input->post('end_distance');

        $start_price = $this->input->post('start_price');

        $end_price = $this->input->post('end_price');

        $category = $this->input->post('category');

        $sub_category = $this->input->post('sub_category');

        $city = $this->input->post('city');

        $_lng = !empty($this->input->post('longitude')) ? $this->input->post('longitude') : 0;

        $_lat = !empty($this->input->post('latitude')) ? $this->input->post('latitude') : 0;


        $where = array(

            'j.user_id!=' => $user_id,

            'j.status' => 'active',

            'u.status' => 'active'

        );

        if ($start_price !== "") {

            $where['j.offer>='] = $start_price;

        }

        if ($end_price !== "") {

            $where['j.offer<='] = $end_price;

        }

        $this->db->select("COUNT(j.id) as total,

         (SELECT COUNT(tbl_job_ignore.id) FROM tbl_job_ignore WHERE tbl_job_ignore.user_id=$user_id AND tbl_job_ignore.job_id=j.id) as job_ignore,

         (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id AND tbl_job_apply.job_id=j.id) as apply, 

         (111.111 * DEGREES(ACOS(COS(RADIANS(j.start_latitude))

                * COS(RADIANS('$_lat'))

                * COS(RADIANS(j.start_longitude - '$_lng'))

                + SIN(RADIANS(j.start_latitude))

                * SIN(RADIANS('$_lat'))))

                ) AS distance")
            ->from('tbl_job j')->join('tbl_users u', 'u.id=j.user_id')->where($where)->having('apply', 0)->having('job_ignore', 0);

        if (!empty($city)) {

            $this->db->group_start()->where('start_city', $city)->or_where('end_city', $city)->group_end();

        }

        if (!empty($category)) {

            $this->db->where_in('j.category_id', explode(',', $category));

        }

        if (!empty($sub_category)) {

            $this->db->where_in('j.sub_category_id', explode(',', $sub_category));
        }

        if (!empty($search)) {

            $this->db->group_start()
                ->like('j.start_city', $search)
                ->or_like('j.start_country', $search)
                ->or_like('j.start_location', $search)
                ->or_like('j.end_location', $search)
                ->or_like('j.end_city', $search)
                ->or_like('j.end_country', $search)
                ->or_like('j.description', $search)
                ->or_like('j.qualification', $search)
                ->or_like('j.skills', $search)
                ->or_like('j.type', $search)
                ->group_end();

        }

        if ($start_distance !== "" && $end_distance !== "") {

            $this->db->having('distance>=', $start_distance)->having('distance<=', $end_distance);

        }

        $data = $this->db->get()->row_array();

        if (is_null($data['total'])) {

            return '0';

        } else {

            return $data['total'];

        }

    }


    public function apply_job($user_id = 0)

    {

        $job_id = $this->input->post('job_id');

        $content = array('status' => 412, 'message' => $this->lang->line('err_something_went_wrong'));

        $get_job_data = $this->common->get_data_by_id('tbl_job', 'id', $job_id, 'id,user_id', array('user_id!=' => $user_id), '', 'ASC', '', 'row');

        if (!empty($get_job_data)) {

            $apply_check = $this->common->get_data_by_id('tbl_job_apply', 'job_id', $job_id, 'id', array('user_id' => $user_id), '', 'ASC', '', 'row');

            if (empty($apply_check)) {

                $proposal = $this->input->post('proposal');

                $insert_data = array(

                    'user_id' => $user_id,

                    'job_id' => $job_id,

                    'proposal' => $proposal,

                    'offer' => $this->input->post('offer'),

                    'created' => get_date(),

                );

                $push_code = array(

                    'push_type' => 1,

                    'push_message' => $this->lang->line('notification_job_applay'),

                    'job_id' => $job_id,

                );

                $content['status'] = 200;

                $content['message'] = $this->lang->line('succ_job_apply');

                $job_apply_id = $this->common->insert_data('tbl_job_apply', $insert_data);

                $this->user_model->add_user_chat($get_job_data['user_id'], $proposal, $user_id, "message", $job_id, $user_id);

                $this->common->upload_attachment($job_apply_id, $user_id, $get_job_data['user_id'], $job_id);

                $this->user_model->add_user_chat($user_id, $this->lang->line('job_apply'), $get_job_data['user_id'], "message", $job_id, $user_id);

                $this->common->send_push_code($get_job_data['user_id'], $user_id, $push_code);

            } else {
                $content['message'] = $this->lang->line('err_job_apply');
            }

        } else {

            $content['message'] = $this->lang->line('err_job_not_found');

        }

        return $content;

    }


    public function get_favourite_list($user_id = 0)

    {

        $where = array(

            'j.status' => 'active',

            'u.status' => 'active',

            'f.user_id' => $user_id,

        );

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');


        $this->db->select("u.name,u.profile_image,j.*,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id AND tbl_job_apply.job_id=j.id) as apply,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.job_id=j.id) as total_apply,

        (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=$user_id AND tbl_threads.iFriendId=j.user_id) OR (tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=$user_id))) as thread_id,sc.name as sub_category_name

        ")
            ->from('tbl_job_fav f')->join('tbl_job j', 'f.job_id=j.id')->join('tbl_category sc', 'sc.id=j.sub_category_id', 'LEFT')->join('tbl_users u', 'u.id=j.user_id')->where($where);

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->order_by('f.id', 'DESC')->get()->result_array();

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                if (empty($value['thread_id'])) {

                    $data[$key]['thread_id'] = '0';

                }
                if (empty($value['sub_category_name'])) {
                    $data[$key]['sub_category_name'] = '';
                }

                $data[$key]['profile_image'] = checkImage(1, $value['profile_image'], 0, 0, false);

                $data[$key]['favourite'] = '1';

            }

        }

        return $data;

    }


    public function get_applied_job_list($user_id = 0)

    {

        $where = array(

            'j.status' => 'active',

            'u.status' => 'active',

            'a.user_id' => $user_id,

        );

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');


        $this->db->select("u.name,u.profile_image,j.*,

        (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE tbl_job_fav.user_id=$user_id AND tbl_job_fav.job_id=j.id) as favourite,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.job_id=j.id) as total_apply,

        (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=$user_id AND tbl_threads.iFriendId=j.user_id) OR (tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=$user_id))) as thread_id,sc.name as sub_category_name,a.offer")
            ->from('tbl_job_apply a')->join('tbl_job j', 'a.job_id=j.id')->join('tbl_category sc', 'sc.id=j.sub_category_id', 'LEFT')->join('tbl_users u', 'u.id=j.user_id')->where($where);

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->order_by('a.id', 'DESC')->get()->result_array();

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                $data[$key]['profile_image'] = checkImage(1, $value['profile_image'], 0, 0, false);

                $data[$key]['apply'] = '1';
                if (empty($value['sub_category_name'])) {
                    $data[$key]['sub_category_name'] = '';
                }


            }

        }

        return $data;

    }


    public function get_completed_job($user_id = 0)

    {

        $where = array(

            'j.status' => 'completed',

            'ap.status' => 'completed',


        );

        $limit = $this->input->post('limit');

        $offset = $this->input->post('offset');

        $this->db->select("u.name,u.profile_image,j.*,ap.offer as frelance_offer,ap.id as apply_id,ap.status as applay_status,ap.proposal,ap.user_id as freelancer_id,f.profile_image as freelancer_image,f.name as freelancer_name,

        (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE tbl_job_fav.user_id=$user_id AND tbl_job_fav.job_id=j.id) as favourite,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id AND tbl_job_apply.job_id=j.id) as apply,

        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.job_id=j.id) as total_apply,

        (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=ap.user_id) OR (tbl_threads.iUserId=ap.user_id AND tbl_threads.iFriendId=j.user_id))) as thread_id,

        ")->from('tbl_job j')->join('tbl_users u', 'u.id=j.user_id')->join('tbl_job_apply ap', 'ap.job_id=j.id')->join('tbl_users f', 'f.id=ap.user_id')
            ->where($where)
            ->group_start()->where('j.user_id', $user_id)->or_where('ap.user_id', $user_id)->group_end();

        if ($limit !== "" && $offset !== "") {

            $this->db->limit($limit, $offset);

        }

        $data = $this->db->get()->result_array();

//        pre($this->db->last_query());

        if (!empty($data)) {

            foreach ($data as $key => $value) {

                if (empty($value['thread_id'])) {

                    $data[$key]['thread_id'] = '0';

                }


                if (empty($value['applay_status'])) {

                    $data[$key]['applay_status'] = 'none';

                    $data[$key]['apply_id'] = '0';

                    $data[$key]['frelance_offer'] = '0';

                    $data[$key]['proposal'] = '';

                }

                $data[$key]['profile_image'] = checkImage(1, $value['profile_image'], 0, 0, false);

                $data[$key]['freelancer_image'] = checkImage(1, $value['freelancer_image'], 0, 0, false);

                $data[$key]['attachment'] = $this->common->get_job_attachment($value['apply_id']);

            }

        }

//        else {

//            pre($this->db->last_query());

//        }

        return $data;

    }


    public function remove_job($user_id = 0)

    {

        $content = array('status' => 412, 'message' => $this->lang->line('err_something_went_wrong'));

        $id = $this->input->post('id');

        $get_job_data = $this->common->get_data_by_id('tbl_job', 'id', $id, '*', array('user_id' => $user_id), '', 'ASC', '', 'row');

        if (!empty($get_job_data)) {

            if ($get_job_data['status'] == 'active') {

                $get_all_threads = $this->common->get_data_by_id('tbl_threads', 'job', $id, '*');

                $get_all_msg_attachment = $this->common->get_data_by_join('tbl_messages m', 'm.iMessageId,m.type,m.vMessage', array('tbl_threads t' => 't.iThreadId=m.iThreadId'),

                    array('t.job' => $id, 'm.type!=' => 'message'));

                $get_all_attachment = $this->common->get_data_by_join('tbl_attachment a', 'a.id,a.file', array('tbl_job_apply ap' => 'ap.id=a.parent_id'), array('ap.job_id' => $id));

                if (!empty($get_all_msg_attachment)) {

                    foreach ($get_all_msg_attachment as $key => $value) {

                        if ($value['type'] == 'attachment') {

                            $file = FCPATH . SITE_UPD . 'attachment' . '/' . $value['vMessage'];

                            if (file_exists($file)) {

                                unlink_file($file);

                            }

                        } else {

                            $file = FCPATH . SITE_UPD . 'chat' . '/' . $value['vMessage'];

                            if (file_exists($file)) {

                                unlink_file($file);

                            }

                        }

                    }

                }

                if (!empty($get_all_attachment)) {

                    foreach ($get_all_attachment as $key => $value) {

                        $file = FCPATH . SITE_UPD . 'attachment' . '/' . $value['file'];

                        if (file_exists($file)) {

                            unlink_file($file);

                        }

                        $this->common->delete_data('tbl_attachment', array('id' => $value['id']));

                    }

                }

                if (!empty($get_all_threads)) {

                    foreach ($get_all_threads as $key => $value) {

                        $this->common->delete_data('tbl_messages', array('iThreadId' => $value['iThreadId']));

                    }

                }

                $this->common->delete_data('tbl_threads', array('job' => $id));

                $this->common->delete_data('tbl_job_apply', array('job_id' => $id));

                $this->common->delete_data('tbl_job_fav', array('job_id' => $id));

                $this->common->delete_data('tbl_job_ignore', array('job_id' => $id));

                $this->common->delete_data('tbl_job_apply', array('job_id' => $id));

                $this->common->delete_data('tbl_job', array('id' => $id));

                $content['message'] = $this->lang->line('succ_job_removed');

            } else {

                $content['message'] = $this->lang->line('err_job_not_delete');

            }

        } else {

            $content['message'] = $this->lang->line('err_job_not_found');

        }

        return $content;

    }
    public function applied_list($job_id = 0){
        // $get_job_da = 34;
        // $this->db->select('*')->from('tbl_job_apply a')->join('tbl_users j', 'a.user_id=j.id', 'LEFT')->where(['a.job_id' => $job_id]);
        // $data = $this->db->order_by('a.id', 'DESC')->get()->result_array();
        // return $data;
        $query = $this->db->query("SELECT u.id as user_id, u.name, u.email, u.city, u.gender, u.age, u.profile_image, u.about, ja.id as offer_id, ja.proposal, ja.offer, ja.job_complete, ja.status, ja.created FROM tbl_job_apply as ja left join tbl_users as u on u.id = ja.user_id where job_id ='". $job_id."'");
        // $query = $this->db->query("select postal_code, unit_number from tbl_user_bank where user_id = '" .$get_job_da . "' limit 1");
        return $query->result_array();
    }

}

