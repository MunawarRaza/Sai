<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class User_model_v1 extends MY_WsModel
{

    protected $_table_name = 'tbl_users';
    protected $_primary_key = 'id';
    protected $_primary_filter = 'intval';
    protected $_order_by = "id DESC";

    function __construct()
    {
        parent::__construct();
    }

    function get_single_user($array)
    {
        $this->_table_name = 'tbl_users';
        $fields = SELECT_DATA;
        $query = parent::get_single($array, $fields);
        return $query;
    }

    function generate_auth($iUserId)
    {
        $data = array();
        $data['key'] = md5($iUserId . time() . rand());
        $data['auth'] = parent::hash($data['key']);
        return $data;
    }

    function insert_device($array)
    {
        $this->_table_name = 'tbl_user_devices';
        $array['dCreatedDate'] = get_date();
        return parent::insert($array);
    }

    function insert_user($array)
    {
        $array['status'] = 'active';
        $array['created'] = get_date();
        $array['updated'] = get_date();
        $this->_table_name = 'tbl_users';
        return parent::insert($array);
    }

    function update_user($data, $id = NULL)
    {
        $data['updated'] = get_date();
        $this->_table_name = 'tbl_users';
        parent::update($data, $id);
        return $id;
    }

    function resetPassword($postArray, $token)
    {
        $this->_table_name = 'tbl_users';
        return $this->db->update($this->_table_name, $postArray, array("token" => $token));
    }

    function check_login($vAuthToken = "")
    {
        $this->_table_name = 'tbl_user_devices';
        $vAuthToken = parent::hash($vAuthToken);
        $query = parent::get_single(array('vAuthToken' => $vAuthToken, 'eStatus' => 'y'));
        return $query;
    }

    function logout($vAuthToken)
    {
        $vAuthToken = parent::hash($vAuthToken);
        $this->_table_name = 'tbl_user_devices';
        $this->db->delete('tbl_user_devices', array('vAuthToken' => $vAuthToken));
    }

    public function register_user($array)
    {
        $token = md5(time() . rand());
        $userData = array(
            'name' => $array['name'],
            'email' => $array['email'],
            'type' => 'user',
            'password' => (isset($array['password'])) ? md5($array['password']) : "",
            'facebook_id' => (isset($array['facebook_id'])) ? $array['facebook_id'] : "",
            'google_id' => (isset($array['google_id'])) ? $array['google_id'] : "",
            'apple_id' => (isset($array['apple_id'])) ? $array['apple_id'] : "",
            'status' => 'active',
            'created' => get_date(),
            'updated' => get_date(),
        );
        return $this->common->insert_data('tbl_users', $userData);
    }

    public function social_login_check($social_type = "", $social_id = '', $email)
    {
        if ($social_type == 'facebook') {
            $this->db->where('facebook_id', $social_id);
        } elseif ($social_type == "google") {
            $this->db->where('google_id', $social_id);
        } else {
            $this->db->where('apple_id', $social_id);
        }
        if (!empty($email)) {
            $this->db->or_where('email', $email);
        }
        return $this->db->get('tbl_users')->row();
    }

    public function notification_listing($user_id = 0)
    {
        $limit = $this->input->post('limit');
        $offset = $this->input->post('offset');
        $where = array(
            'n.user_id' => $user_id
        );
        $this->db->select('n.*')->From('tbl_notification n')->where($where);
        if ($limit !== "" && $offset !== "") {
            $this->db->limit($limit, $offset);
        }
        $data = $this->db->order_by('n.id', 'DESC')->get()->result_array();
        $this->common->update_data(array('read_flag' => 1), 'tbl_notification', 'user_id', $user_id);
        return $data;
    }

    public function get_profile_data($user_id = 0)
    {
        $today_date = $this->input->post('date');
        if (empty($date)) {
            $today_date = date('Y-m-d');
        }

        $query = $this->db->select("u.id,u.name,u.profile_image,u.city,
        (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE tbl_job_fav.user_id=$user_id) as favorite,
        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id) as applied,
        (SELECT SUM(tbl_transaction.amount) FROM tbl_transaction WHERE tbl_transaction.type='payment_get' AND DATE(tbl_transaction.updated)='$today_date' AND tbl_transaction.status='completed') as today_earning,
        (SELECT SUM(tbl_transaction.amount) FROM tbl_transaction WHERE tbl_transaction.type='payment_get' AND tbl_transaction.status='completed') as total_earning,")
            ->from('tbl_users u')->where('u.id', $user_id)->get()->row_array();
        if (!empty($query)) {
            $query['profile_image'] = checkImage(1, $query['profile_image'], 0, 0, false);
            if (empty($query['today_earning'])) {
                $query['today_earning'] = '0';
            }
            if (empty($query['total_earning'])) {
                $query['total_earning'] = '0';
            }
            $query['job'] = $this->get_user_posted_job($user_id, 5, 0, $user_id);
        }
        return $query;
    }

    public function get_user_posted_job($user_id = 0, $limit = 5, $offset = 0, $my_id = 0)
    {

        $where = array('j.user_id' => $user_id, 'j.status != ' => 'inactive');
        $this->db->select("u.name,u.profile_image,j.*,
                (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE tbl_job_fav.user_id=$my_id AND tbl_job_fav.job_id=j.id) as favourite,
                (SELECT COUNT(tbl_job_ignore.id) FROM tbl_job_ignore WHERE tbl_job_ignore.user_id=$my_id AND tbl_job_ignore.job_id=j.id) as job_ignore,
                (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$my_id AND tbl_job_apply.job_id=j.id) as apply,
                (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.job_id=j.id) as total_apply,
                (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=$my_id AND tbl_threads.iFriendId=j.user_id) OR (tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=$my_id))) as thread_id,sc.name as sub_category_name,
                ")
            ->from('tbl_job j')->join('tbl_category sc', 'sc.id=j.sub_category_id', 'LEFT')->join('tbl_users u', 'u.id = j.user_id')->where($where);
        if ($limit !== "" && $offset !== "") {
            $this->db->limit($limit, $offset);
        }
        $data = $this->db->order_by('j.id', 'DESC')->get()->result_array();
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $data[$key]['profile_image'] = checkImage(1, $value['profile_image'], 0, 0, false);
                if (empty($value['thread_id'])) {
                    $data[$key]['thread_id'] = '0';
                }
                if (empty($value['sub_category_name'])) {
                    $data[$key]['sub_category_name'] = '';
                }
            }
        }
        return $data;
    }

    public function wallet_list($user_id = 0)
    {
        $data = array();
        $data['bank_service_charge'] = FREELANCER_FEE;
        $user_data = $this->common->get_data_by_id('tbl_users', 'id', $user_id, 'amount', array(), '', 'ASC', '', 'row');
        $data['wallet_amount'] = $user_data['amount'];
        $data['card_list'] = $this->common->get_data_by_id('tbl_user_card', 'user_id', $user_id, '*', array(), 'id', 'DESC', '');
        $data['bank_list'] = $this->common->get_data_by_id('tbl_user_bank', 'user_id', $user_id, '*', array(), 'id', 'DESC', '');
        $data['transaction_list'] = $this->transaction_listing($user_id, 10, 0);
        return $data;
    }

    public function transaction_listing($user_id = 0, $limit = 0, $offset = 0)
    {
        $where = array(
            't.user_id' => $user_id
        );
        $this->db->select('t.*,u.profile_image,u.name as user_name,IF(c.name IS NULL,"",c.name) as category,IF(sc.name IS NULL,"",sc.name) as sub_category')->from('tbl_transaction t')
            ->join('tbl_job j', 'j.id=t.job_id', 'LEFT')
            ->join('tbl_category c', 'c.id=j.category_id', 'LEFT')
            ->join('tbl_category sc', 'sc.id=j.sub_category_id', 'LEFT')
            ->join('tbl_users u', 'u.id=j.user_id', "LEFT")
            ->where($where);
        if ($limit !== "" && $offset !== "") {
            $this->db->limit($limit, $offset);
        }
        $data = $this->db->order_by('t.id', 'DESC')->get()->result_array();
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                if (!empty($value['profile_image'])) {
                    $data[$key]['image'] = checkImage(1, $value['profile_image'], 0, 0, false);
                } else {
                    $data[$key]['profile_image'] = '';
                    $data[$key]['image'] = base_url('themes/uploads/transaction/wallet.png');
                }
                $data[$key]['charge'] = number_format($value['charge'], 2, '.', '');
                if (in_array($value['type'], ['wallet_payment', 'card_payment', 'apple_pay'])) {
                    $data[$key]['new_amount'] = number_format($value['amount'] + $value['charge'], 2, '.', '');
                } else {
                    $data[$key]['new_amount'] = number_format($value['amount'] - $value['charge'], 2, '.', '');
                }
                $data[$key]['amount'] = number_format($value['amount'], 2, '.', '');
                $data[$key]['sub_description'] = $value['sub_description'] ? $value['sub_description'] : "";
            }
        }
        return $data;
    }

    public function add_card($user_id = 0)
    {
        $content = array('status' => 412, 'message' => $this->lang->language['err_something_went_wrong'], 'data' => new stdClass());
        $master_customer = $this->common->customer_master_stripe($user_id);
        if ($master_customer['status'] == 200) {
            $customer_id = $master_customer;
            $card_id = $master_customer['card_id'];
            $card_primary = $this->input->post('is_primary');
            if ($card_primary > 0) {
                $card_primary = 1;
            } else {
                $card_primary = 0;
            }
            $card_data = array(
                'user_id' => $user_id,
                'card_number' => $this->input->post('card_number'),
                'expire_month' => $this->input->post('expire_month'),
                'expire_year' => $this->input->post('expire_year'),
                'card_token' => $card_id,
                'is_primary' => $card_primary,
                'created' => get_date(),
            );
            $content['status'] = 200;
            $content['message'] = $this->lang->line('succ_card_added');
            $last_card_id = $this->common->insert_data('tbl_user_card', $card_data);
            if ($card_primary > 0) {
                $this->common->new_update_data(array('is_primary' => 0), 'tbl_user_card', array('id!=' => $last_card_id, 'user_id' => $user_id));
            }
            $content['data'] = $this->common->get_data_by_id('tbl_user_card', 'id', $last_card_id, '*', array(), '', 'ASC', '', 'row');
        } else {
            $content['message'] = $master_customer['message'];
        }
        return $content;
    }

    public function get_graph_data($user_id = 0)
    {
        $data = array();
        $where = array('t.user_id' => $user_id, 't.type' => 'payment_get');
        $data = $this->db->select('t.created as date,(select SUM(tbl_transaction.amount) from tbl_transaction WHERE DATE(t.created)=DATE(tbl_transaction.created)) as amount')
            ->from('tbl_transaction t')->where($where)->order_by('t.id', 'DESC')
            ->group_by('DATE(t.created)')->get()->result_array();
        return $data;
    }

    public function get_chatHistory($PostData = array(), $iUserId)
    {
        $result = array();
        $data = $this->db->get_where('tbl_threads', array('iThreadId' => $PostData['iThreadId']))->row_array();


        $q = $this->db->query("SELECT *,CASE
    WHEN iSenderId = $iUserId THEN Sender_deleted
    ELSE Receiver_deleted END AS chat_deleted
     FROM tbl_messages WHERE iThreadId = ?  HAVING chat_deleted = 0 ORDER BY iMessageId ASC", array($PostData['iThreadId']));

        if ($data['iUserId'] == $iUserId) {
            $this->db->update('tbl_messages', array('eStatus' => 'read'), array('iThreadId' => $PostData['iThreadId'], 'iReceiverId' => $iUserId, 'eSenderStatus' => 'y'));
        } else {
            $this->db->update('tbl_messages', array('eStatus' => 'read'), array('iThreadId' => $PostData['iThreadId'], 'iReceiverId' => $iUserId, 'eReceiverStatus' => 'y'));
            // $q = $this->db->query('SELECT * FROM tbl_messages WHERE iThreadId = ? ORDER BY iMessageId ASC', array($PostData['iThreadId']));
        }
        if ($q->num_rows() > 0) {
            $result = $q->result_array();
        }
        // pre($result);
        return $result;
    }

    public function add_chat($to_user_id = 0, $msg = "", $from_id = 0)
    {
        $type = $this->input->post('type');

        $result = array();
        $q = $this->db->query('SELECT iThreadId FROM tbl_threads WHERE (iUserId = ? OR iFriendId = ?) AND (iUserId = ? OR iFriendId = ?)', array($from_id, $from_id, $to_user_id, $to_user_id));

        if ($q->num_rows() === 1) {
            $result = $q->row_array();
            $id = $result['iThreadId'];
            $this->db->update('tbl_threads', array('eUserStatus' => 'y', 'eFriendStatus' => 'y'), array('iThreadId' => $id));
        } else {
            $this->db->insert('tbl_threads', array('iUserId' => $from_id, 'iFriendId' => $to_user_id, 'eIsactive' => 'y', 'dCreatedDate' => date('Y-m-d H:i:s')));
            $id = $this->db->insert_id();
        }

        if ($id > 0) {
            $this->db->insert('tbl_messages', array('iThreadId' => $id, 'iSenderId' => $from_id, 'iReceiverId' => $to_user_id,
                'vMessage' => $msg, 'dCreatedDate' => date('Y-m-d H:i:s')));
            $r = $this->db->insert_id();
            if ($r > 0) {
                $q = $this->db->query('SELECT * FROM tbl_messages WHERE iMessageId = ?', $r);
                if ($q->num_rows() === 1) {
                    $result = $q->row_array();
                }
            }
        }
        return $result;
    }

    public function get_threadList($array)
    {
        $result = array();
        $search = $this->input->post('search');
        $user_id = $array['iUserId'];
        $limit = $array['iLimit'];
        $offset = $array['iOffset'];
        $query = "SELECT m.iThreadId,m.iSenderId,m.iReceiverId,m.eStatus,m.dCreatedDate,u.profile_image,u.name,u.id as iToUserId,t.job,
        (SELECT COUNT(tbl_job.id) FROM tbl_job WHERE status='inactive' and tbl_job.id=t.job) as job_closed,
            (SELECT type FROM tbl_messages WHERE iThreadId = t.iThreadId ORDER BY iMessageId DESC LIMIT 1 OFFSET 0) as type,
            (SELECT vMessage FROM tbl_messages WHERE iThreadId = t.iThreadId 
            AND ((tbl_messages.iSenderId=$user_id AND tbl_messages.Sender_deleted=0) OR (tbl_messages.iReceiverId=$user_id AND tbl_messages.Receiver_deleted=0)) 
            ORDER BY iMessageId DESC LIMIT 1 OFFSET 0) as vMessage,
            (SELECT iMessageId FROM tbl_messages WHERE iThreadId = t.iThreadId AND ((tbl_messages.iSenderId=$user_id AND tbl_messages.Sender_deleted=0) OR (tbl_messages.iReceiverId=$user_id AND tbl_messages.Receiver_deleted=0))
             ORDER BY iMessageId DESC LIMIT 1 OFFSET 0) as iMessageId,
            (SELECT COUNT(iMessageId) FROM tbl_messages WHERE eStatus = 'unread' AND iReceiverId = '$user_id' AND iSenderId = u.id AND iThreadId = t.iThreadId) as unread_count
            FROM tbl_threads as t
                                INNER JOIN tbl_users as u ON((t.iUserId = u.id AND t.iFriendId = ?) OR (t.iFriendId = u.id AND t.iUserId = ?))
                                INNER JOIN(SELECT * FROM tbl_messages WHERE 1 ORDER BY iMessageId DESC) as m ON(m.iThreadId = t.iThreadId)
                                WHERE IF (t.iUserId = '$user_id', t.eUserStatus, t.eFriendStatus) = 'y' AND t.job_seeker_id != 0";
        if (!empty($search)) {
            $query .= " AND (u.name LIKE '$search%') ";
        }
        $query .= " GROUP BY t.iThreadId HAVING job_closed = 0 ORDER BY iMessageId DESC LIMIT $limit OFFSET $offset";

        $q = $this->db->query($query, array($array['iUserId'], $array['iUserId']));

        if ($q->num_rows() > 0) {
            $result = $q->result_array();
        }
        return $result;
    }

    public function add_user_chat_22_07_2020($to_user_id = 0, $msg = "", $from_id = 0, $type = "message", $job_id = "0", $job_seeker_id = 0)
    {
        $result = array();
        $q = $this->db->query('SELECT iThreadId FROM tbl_threads WHERE(iUserId = ? OR iFriendId = ?) AND (iUserId = ? OR iFriendId = ?) AND job =?', array($from_id, $from_id, $to_user_id, $to_user_id, $job_id));
        if ($q->num_rows() === 1) {
            $result = $q->row_array();
            $id = $result['iThreadId'];
            $this->db->update('tbl_threads', array('eUserStatus' => 'y', 'eFriendStatus' => 'y'), array('iThreadId' => $id));
        } else {
            $this->db->insert('tbl_threads', array('iUserId' => $from_id, 'job' => $job_id, 'iFriendId' => $to_user_id, 'eIsactive' => 'y', 'job_seeker_id' => $job_seeker_id, 'dCreatedDate' => date('Y - m - d H:i:s')));
            $id = $this->db->insert_id();
        }
        if ($id > 0) {
            $message_in = array('iThreadId' => $id,
                'iSenderId' => $from_id,
                'iReceiverId' => $to_user_id,
                'type' => $type,
                'dCreatedDate' => get_date());
            if ($type == "message") {
                $message_in['vMessage'] = $msg;
            } else {
                if (isset($_FILES['attachment']) && !empty($_FILES['attachment']['name'])) {
                    $this->load->library('upload');
                    $this->load->library('image_lib');
                    $file_config = array();
                    if ($type == 'attachment') {
                        $path = FCPATH . SITE_UPD . 'attachment';
                    } else {
                        $path = FCPATH . SITE_UPD . 'chat';
                    }
                    if (!file_exists($path)) {
                        @mkdir($path);
                    }
                    $file_config['upload_path'] = $path;
                    $file_config['allowed_types'] = '*';
                    $file_config['overwrite'] = TRUE;
                    $file_config['max_size'] = '204800';
                    $file_config['file_name'] = md5(time() . rand());
                    $this->upload->initialize($file_config);
                    if ($this->upload->do_upload('attachment')) {
                        $content['status'] = 200;
                        $upload_data = $this->upload->data();
                        $message_in['vMessage'] = $upload_data['file_name'];
                    } else {
                        $message_in['vMessage'] = '';
                    }
                } else {
                    $message_in['vMessage'] = '';
                }
            }
            $r = $this->common->insert_data('tbl_messages', $message_in);
            $chat_g_data = $this->db->where('iMessageId', $r)->get('tbl_messages')->row();
            $r = $chat_g_data->iThreadId;
            if ($r > 0) {
                $q = $this->db->query('SELECT * FROM tbl_threads WHERE iThreadId = ?', $r);
                if ($q->num_rows() === 1) {
                    $result = $q->row_array();
                    $result['vMessage'] = $msg;
                }
            }
        }
        return $result;
    }

    public function get_single_job_chat($thread_id, $user_id)
    {

        $data = $this->db->query('SELECT m.iThreadId,m.iSenderId,m.iReceiverId,m.eStatus,m.dCreatedDate,u.profile_image,u.name,u.id as iToUserId,t.job,
            (SELECT COUNT(tbl_job.id) FROM tbl_job WHERE status = "inactive" and tbl_job.id = t.job) as job_closed,
            (SELECT type FROM tbl_messages WHERE iThreadId = t.iThreadId ORDER BY iMessageId DESC LIMIT 1 OFFSET 0) as type,
            (SELECT vMessage FROM tbl_messages WHERE iThreadId = t.iThreadId ORDER BY iMessageId DESC LIMIT 1 OFFSET 0) as vMessage,
            (SELECT iMessageId FROM tbl_messages WHERE iThreadId = t.iThreadId ORDER BY iMessageId DESC LIMIT 1 OFFSET 0) as iMessageId,
                                (SELECT COUNT(iMessageId) FROM tbl_messages WHERE eStatus = "unread" AND iReceiverId = ' . $user_id . ' AND iSenderId = u.id AND iThreadId = t.iThreadId) as unread_count
                                FROM tbl_threads as t
                                INNER JOIN tbl_users as u ON((t.iUserId = u.id AND t.iFriendId = ?) OR (t.iFriendId = u.id AND t.iUserId = ?))
                                INNER JOIN(SELECT * FROM tbl_messages WHERE 1 ORDER BY iMessageId DESC) as m ON(m.iThreadId = t.iThreadId)
                                WHERE IF (t.iUserId = ' . $user_id . ', t.eUserStatus, t.eFriendStatus) =  "y" AND t.iThreadId = ' . $thread_id . '
                                GROUP BY t.iThreadId HAVING job_closed = 0 ORDER BY iMessageId DESC', array($user_id, $user_id))->row();
        if (!empty($data)) {
            $data->profile_image = checkImage(1, $data->profile_image, 0, 0, false);
            $data->job_data = $this->get_chat_job_data($thread_id, $user_id);
        }
        return $data;
    }

    public function get_chat_job_data($thread_id = 0, $user_id = 0)
    {
        $job_data = $this->common->get_data_by_join('tbl_threads t', "u.name,u.profile_image,j.*,ap.offer as frelance_offer,
        ap.id as apply_id,ap.status as applay_status,ap.proposal,ap.job_complete,
        (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE j.user_id=ap.user_id AND tbl_job_fav.job_id=j.id) as favourite,", array('tbl_job j' => "j.id=t.job", 'tbl_users u' => 'u.id = j.user_id', 'tbl_job_apply ap' => "ap.user_id=t.job_seeker_id AND ap.job_id=j.id"), array('t.iThreadId' => $thread_id), '', 'ASC', '', '', 'row');
        if (empty($job_data)) {
            $job_data = new stdClass();
        } else {

            if (empty($job_data['applay_status'])) {
                $job_data['applay_status'] = 'none';
                $job_data['apply_id'] = '0';
                $job_data['job_complete'] = '0';
                $job_data['frelance_offer'] = '0';
                $job_data['proposal'] = '';
            }
            $job_data['sub_category_name'] = '';
            $subactegory = $this->common->get_data_by_id('tbl_category', 'id', $job_data['sub_category_id'], '*', array(), '', '', '', 'row');
            if (!empty($subactegory)) {
                $job_data['sub_category_name'] = $subactegory['name'];
            }
            $job_data['profile_image'] = checkImage(1, $job_data['profile_image'], 0, 0, false);
            $job_data['attachment'] = $this->common->get_job_attachment($job_data['apply_id']);
        }
        return $job_data;
    }

    public function action_job($user_id = 0)
    {
        $apply_id = $this->input->post('apply_id');
        $type = $this->input->post('type');
        $content = array('status' => 412, 'message' => $this->lang->line('err_something_went_wrong'));
        $get_job_data = $this->common->get_data_by_join('tbl_job_apply ap',
            "j.type as job_type,j.client_fee,ap.offer as freelancer_offer,j.id,j.status,ap.status as apply_status,ap.user_id as freelancer_id,
        ap.job_complete,j.user_id as owner_id,
        (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=ap.user_id) OR (tbl_threads.iUserId=ap.user_id AND tbl_threads.iFriendId=j.user_id))) as thread_id,
        ", array('tbl_job j' => 'j.id = ap.job_id'), array('ap.id' => $apply_id, 'j.status != ' => 'inactive'), '', 'ASC', '', '', 'row');
//        'j.user_id' => $user_id
        if (!empty($get_job_data)) {
            if (is_null($get_job_data['thread_id'])) {
                $get_job_data['thread_id'] = '0';
            }

            if ($get_job_data['apply_status'] == 'pending' && $get_job_data['owner_id'] == $user_id) {
                if ($type == 'accept') {
                    $payment_check = $this->take_a_payment($user_id, $get_job_data);
                    if ($payment_check['status'] == 200) {
                        $content['status'] = 200;
                        $content['message'] = $this->lang->line('job_proposal_accepted');
                        $push_msg = $this->lang->line('job_approve');
                        $push_msg_type = $this->lang->line('job_approve_push');
                        $type = "accepted";
                        $fName = "";
                        $fdata = $this->common->get_data_by_id('tbl_users', 'id', $get_job_data['freelancer_id'], '*', array(), '', '', '', 'row');
                        if (!empty($fdata))
                            $fName = $fdata['name'];
                        $this->common->update_data(array('status' => 'running', 'transaction_id' => $payment_check['id']), 'tbl_job', 'id', $get_job_data['id']);
//                        $check = $this->add_user_chat($user_id, "You've approved the offer. " . $fName . " is working hard to complete the gig.", $get_job_data['freelancer_id'], "message", $get_job_data['id']);
                        $check = $this->add_user_chat($get_job_data['freelancer_id'], $push_msg, $user_id, "message", $get_job_data['id']);
                        if (!empty($check)) {
                            $this->send_push_chat($check['iThreadId'], $user_id, $get_job_data['freelancer_id'], $push_msg_type);
                        }
                        $this->common->new_update_data(array('status' => 'closed'), 'tbl_job_apply', array('status != ' => 'rejected'));
                        $this->common->update_data(array('status' => $type, 'is_prev_rejected' => 0), 'tbl_job_apply', 'id', $apply_id);
                        $notification = array(
                            'user_id' => $get_job_data['freelancer_id'],
                            'job_id' => $get_job_data['id'],
                            'thread_id' => $get_job_data['thread_id'],
                            'from_user_id' => $user_id,
                            'push_message' => str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('succ_notification_accepted')),
                            'push_from' => SITENAME,
                            'insert_date' => get_date()
                        );
                        $this->common->insert_data('tbl_notification', $notification);
                    } else {
                        $content = $payment_check;
                    }
                } elseif ($type == 'reject' && $get_job_data['owner_id'] == $user_id) {
                    $content['status'] = 200;
                    $content['message'] = $this->lang->line('job_proposal_rejected');
                    $push_msg = $this->lang->line('job_rejected');
                    $push_msg_type = $this->lang->line('job_rejected_push');
                    $type = "rejected";
                    $check = $this->add_user_chat($user_id, "You�ve rejected the offer.", $get_job_data['freelancer_id'], "message", $get_job_data['id']);
                    $check = $this->add_user_chat($get_job_data['freelancer_id'], 'Your offer has been rejected. Share your portfolios and past experiences with the hirer on your next offer.', $user_id, "message", $get_job_data['id']);
//                    $check = $this->add_user_chat($get_job_data['freelancer_id'], $push_msg, $user_id, "message", $get_job_data['id']);
                    if (!empty($check)) {
                        $this->send_push_chat($check['iThreadId'], $user_id, $get_job_data['freelancer_id'], $push_msg_type);
                    }
                    $this->common->update_data(array('status' => $type, 'is_prev_rejected' => 1), 'tbl_job_apply', 'id', $apply_id);
                } else {
                    $content['message'] = $this->lang->line('err_please_enter_valid_parameter');
                }
            } elseif ($get_job_data['apply_status'] == 'accepted') {
                if ($get_job_data['owner_id'] == $user_id) {
                    if ($type == "complete") {
                        if ($get_job_data['job_complete'] == 1) {
                            $push_msg_type = str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('Type_job_completed'));
                            $push_msg = $this->lang->line('job_completed');
                            $post_job_data = $this->common->get_data_by_id('tbl_job', 'id', $get_job_data['id'], '*', array(), '', '', '', 'row');
                            $postUserName = "";
                            $applyUserName = "";
                            $applyUserCity = "";
                            $jobDate = "";
                            $category_name = "";
                            $sub_category_name = "";
                            if (!empty($post_job_data)) {
                                $jobDate = date('d/m/Y', strtotime($post_job_data['created']));
                                $postUserData = $this->common->get_data_by_id('tbl_users', 'id', $get_job_data['owner_id'], '*', array(), '', '', '', 'row');
                                if (!empty($postUserData)) {
                                    $postUserName = $postUserData['name'];
                                }
                                $applyUserData = $this->common->get_data_by_id('tbl_users', 'id', $get_job_data['freelancer_id'], '*', array(), '', '', '', 'row');
                                if (!empty($applyUserData)) {
                                    $applyUserName = $applyUserData['name'];
                                    $applyUserCity = $applyUserData['city'];
                                }
                                $category_p_data = $this->common->get_data_by_id('tbl_category', 'id', $post_job_data['category_id'], '*', array(), '', '', '', 'row');
                                if ($category_p_data) {
                                    $category_name = $category_p_data['name'];
                                }
                                $category_sub_data = $this->common->get_data_by_id('tbl_category', 'id', $post_job_data['sub_category_id'], '*', array(), '', '', '', 'row');
                                if ($category_sub_data) {
                                    $sub_category_name = $category_sub_data['name'];
                                }
                            }
                            $jdata = $get_job_data;
                            $jdata['description'] = $category_name . ' - ' . $sub_category_name;
//                            $jdata['description'] = $push_msg_type;
                            $jdata['payment_type'] = 'Wallet';
                            $jdata['job_posted_by'] = $postUserName;
                            $admin_per = calculate_percentage($get_job_data['freelancer_offer'], FREELANCER_FEE);
                            $iData = array(
                                'username' => $applyUserName,
                                'address' => $applyUserCity,
                                'invoice_code' => "#" . $get_job_data['id'],
                                'date' => $jobDate,
                                'item' => $jdata['description'],
                                'total' => $get_job_data['freelancer_offer'] - $admin_per,
                                'price' => $get_job_data['freelancer_offer'],
                                'charge' => $admin_per,
                            );
                            $invoice_url = $this->gen_invoice($iData);
                            $insert_transaction = array(
                                'user_id' => $get_job_data['freelancer_id'],
                                'amount' => $iData['price'],
                                'charge' => $admin_per,
                                'description' => $jdata['description'],
                                'type' => 'payment_get',
                                'job_id' => $get_job_data['id'],
                                'status' => 'completed',
                                'transaction_id' => genUniqueStr('Wallet_', 18, 'tbl_job', 'transaction_id'),
                                'invoice_url' => $invoice_url,
                                'sub_description' => 'Sent by ' . $postUserName,
                                'created' => get_date(),
                                'updated' => get_date(),
                            );
                            $content['status'] = 200;
                            $content['message'] = $this->lang->line('job_proposal_completed');
                            $this->common->update_data(array('status' => 'completed'), 'tbl_job', 'id', $get_job_data['id']);
                            $this->common->update_data(array('status' => 'completed'), 'tbl_job_apply', 'id', $apply_id);
                            $check = $this->add_user_chat($get_job_data['freelancer_id'], "Your work has been approved here's an invoice for your service contribution thank you!", $user_id, "message", $get_job_data['id']);
//                            $check = $this->add_user_chat($get_job_data['freelancer_id'], $push_msg, $user_id, "message", $get_job_data['id']);
                            $this->common->add_amount_to_wallet($get_job_data['freelancer_id'], $insert_transaction['amount']);
                            $this->common->insert_data('tbl_transaction', $insert_transaction);
                            if (!empty($check)) {
                                $this->send_push_chat($check['iThreadId'], $user_id, $get_job_data['freelancer_id'], $push_msg_type);
                            }
                            $notification = array(
                                'user_id' => $get_job_data['freelancer_id'],
                                'job_id' => $get_job_data['id'],
                                'thread_id' => $get_job_data['thread_id'],
                                'from_user_id' => $user_id,
                                'push_message' => str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('succ_notification_completed')),
                                'push_from' => SITENAME,
                                'insert_date' => get_date()
                            );
                            $this->common->insert_data('tbl_notification', $notification);
                        } else {
                            $content['message'] = $this->lang->line('err_job_not_completed');
                        }
                    } elseif ($type == "reject_work") {
                        if ($get_job_data['job_complete'] == 1) {
                            $push_msg_type = str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('err_not_approved'));
                            $this->common->update_data(array('job_complete' => '0'), 'tbl_job_apply', 'id', $apply_id);
                            $check = $this->add_user_chat($get_job_data['freelancer_id'], $push_msg_type, $user_id, "message", $get_job_data['id']);
                            if (!empty($check)) {
                                $this->send_push_chat($check['iThreadId'], $user_id, $get_job_data['freelancer_id'], $push_msg_type);
                            }
                            $notification = array(
                                'user_id' => $get_job_data['freelancer_id'],
                                'job_id' => $get_job_data['id'],
                                'thread_id' => $get_job_data['thread_id'],
                                'from_user_id' => $user_id,
                                'push_message' => $push_msg_type,
                                'push_from' => SITENAME,
                                'insert_date' => get_date()
                            );
                            $this->common->insert_data('tbl_notification', $notification);
                            $content['status'] = 200;
                            $content['message'] = $this->lang->line('succ_job_disapproved');
                        } else {
                            $content['message'] = $this->lang->line('err_job_not_completed');
                        }
                    } else {
                        $content['message'] = $this->lang->line('err_please_enter_valid_parameter');
                    }
                } elseif ($get_job_data['freelancer_id'] == $user_id && $type == 'complete_work') {
                    if ($get_job_data['job_complete'] == 0) {
                        $push_msg_type = str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('job_completed_succfully'));
                        $this->common->update_data(array('job_complete' => '1'), 'tbl_job_apply', 'id', $apply_id);
                        $check = $this->add_user_chat($get_job_data['owner_id'], $push_msg_type, $user_id, "message", $get_job_data['id']);
                        if (!empty($check)) {
                            $this->send_push_chat($check['iThreadId'], $user_id, $get_job_data['owner_id'], $push_msg_type);
                        }
                        $notification = array(
                            'user_id' => $get_job_data['owner_id'],
                            'job_id' => $get_job_data['id'],
                            'thread_id' => $get_job_data['thread_id'],
                            'from_user_id' => $user_id,
                            'push_message' => $push_msg_type,
                            'push_from' => SITENAME,
                            'insert_date' => get_date()
                        );
                        $this->common->insert_data('tbl_notification', $notification);
                        $content['status'] = 200;
                        $content['message'] = $this->lang->line('succ_job_is_completed_req');
                    } else {
                        $content['message'] = $this->lang->line('err_job_complete_req');
                    }
                } else {
                    $content['message'] = $this->lang->line('err_please_enter_valid_parameter');
                }
            } elseif ($get_job_data['apply_status'] == 'completed') {
                $content['message'] = $this->lang->line('err_job_is_completed');
            } elseif ($get_job_data['apply_status'] == 'closed') {
                $content['message'] = $this->lang->line('err_job_close');
            } else {
                $content['message'] = $this->lang->line('err_already_rejected');
            }
        } else {
            $content['message'] = $this->lang->line('err_job_not_found');
        }
        return $content;
    }

    public function take_a_payment($user_id = 0, $get_job_data = array())
    {
        $post_job_data = $this->common->get_data_by_id('tbl_job', 'id', $get_job_data['id'], '*', array(), '', '', '', 'row');
        $postUserName = "";
        $applyUserName = "";
        $applyUserCity = "";
        $jobDate = "";
        $category_name = "";
        $sub_category_name = "";
        $postel_code = "";
        $unit_number = "";

        if (!empty($post_job_data)) {
            $jobDate = date('d/m/Y', strtotime($post_job_data['created']));
            $postUserData = $this->common->get_data_by_id('tbl_users', 'id', $post_job_data['user_id'], '*', array(), '', '', '', 'row');
            if (!empty($postUserData)) {
                $postUserName = $postUserData['name'];
            }
            $applyUserData = $this->common->get_data_by_id('tbl_users', 'id', $get_job_data['freelancer_id'], '*', array(), '', '', '', 'row');
            if (!empty($applyUserData)) {
                $applyUserName = $applyUserData['name'];
                $applyUserCity = $applyUserData['city'];
            }
            $query = $this->db->query("select postal_code, unit_number from tbl_user_bank where user_id = '" .$get_job_da . "' limit 1");
            $bankdata = $query->result_array();
            if($bankdata){
                $postel_code = $bankdata['postal_code'];
                $unit_number = $bankdata['unit_number'];
            }
            $category_p_data = $this->common->get_data_by_id('tbl_category', 'id', $post_job_data['category_id'], '*', array(), '', '', '', 'row');
            if ($category_p_data) {
                $category_name = $category_p_data['name'];
            }
            $category_sub_data = $this->common->get_data_by_id('tbl_category', 'id', $post_job_data['sub_category_id'], '*', array(), '', '', '', 'row');
            if ($category_sub_data) {
                $sub_category_name = $category_sub_data['name'];
            }
        }
        $content = array('status' => 412, 'message' => $this->lang->line('err_something_went_wrong'), 'id' => 0);
        $amount = calculation_percentage($get_job_data['freelancer_offer'], $get_job_data['client_fee']);
        $payment_type = $this->input->post('payment_type');
        $jdata = $get_job_data;
        $jdata['description'] = $category_name . ' - ' . $sub_category_name;
//        $jdata['description'] = str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('job_payment_successfully'));
        $jdata['payment_type'] = (empty($payment_type)) ? 'Wallet' : 'Card';
        $jdata['job_posted_by'] = $postUserName;
        $iData = array(
            'username' => $applyUserName,
            'address' => $applyUserCity,
            'invoice_code' => "#" . $get_job_data['id'],
            'date' => $jobDate,
            'item' => $jdata['description'],
            'price' => $get_job_data['freelancer_offer'],
            'total' => $amount,
            'charge' => $amount - $get_job_data['freelancer_offer'],
            'postal_code' => $postel_code,
            'unit_number' => $unit_number,
        );
        $invoice_url = $this->gen_invoice($iData);
        $insert_transaction = array(
            'user_id' => $user_id,
            'amount' => $get_job_data['freelancer_offer'],
            'charge' => $iData['charge'],
            'description' => $jdata['description'],
//            'description' => str_replace('{{TYPE}}', $get_job_data['job_type'], $this->lang->line('job_payment_successfully')),
            'job_id' => $get_job_data['id'],
            'status' => 'completed',
            'type' => (empty($payment_type)) ? 'wallet_payment' : 'card_payment',
            'invoice_url' => $invoice_url,
            'sub_description' => 'Sent to ' . $applyUserName,
            'created' => get_date(),
            'updated' => get_date(),
        );

        if (empty($payment_type)) {
            $get_user_data = $this->common->get_data_by_id('tbl_users', 'id', $user_id, ' * ', array(), '', 'ASC', '', 'row');
            if (!empty($get_user_data)) {
                $user_wallet_amount = $get_user_data['amount'];
                if ($user_wallet_amount >= $amount) {
                    $transaction_id = genUniqueStr('Wallet_', 18, 'tbl_job', 'transaction_id');
                    $insert_transaction['transaction_id'] = $transaction_id;
                    $content['status'] = 200;
                    $content['id'] = $transaction_id;
                    $this->common->cut_amount_to_wallet($user_id, $amount, $user_wallet_amount);
                    $this->common->insert_data('tbl_transaction', $insert_transaction);
                } else {
                    $content['message'] = $this->lang->line('err_wallet_balance_not');
                }
            }
        } elseif ($payment_type == 2) {
            $content['status'] = 200;
            $content['message'] = $this->lang->line('succ');
            $insert_transaction['type'] = 'apple_pay';
            $insert_transaction['transaction_id'] = $this->input->post('trancation_id');
            $this->common->insert_data('tbl_transaction', $insert_transaction);
        } else {
            $get_card_details = $this->common->get_data_by_join('tbl_user_card c', 'c.id,c.card_token,u.customer_id', array('tbl_users u' => 'u.id = c.user_id'), array('c.is_primary' => 1, 'user_id' => $user_id), '', 'ASC', '', '', 'row');
            if (!empty($get_card_details)) {
                $customer_id = $get_card_details['customer_id'];
                $card_token = $get_card_details['card_token'];
                $update_card = $this->stripe->update_user_card($customer_id, $card_token);
                if ($update_card['status'] == 200) {
                    $content = $this->stripe->charge_user($amount, $customer_id);
                    if ($content['status'] == 200) {
                        $this->common->insert_data('tbl_transaction', $insert_transaction);
                    }
                } else {
                    $content['message'] = $update_card['message'];
                }
            } else {
                $content['message'] = $this->lang->language['err_primary_card_not_found'];
            }
        }
        return $content;
    }

    public function gen_invoice($job_data = array())
    {
        $this->load->library('M_pdf');
        $this->m_pdf->load('utf-8', 'A4');
        $this->m_pdf->pdf->SetDisplayMode('fullpage');
        $html = '<!DOCTYPE html><html><head><meta charset="windows-1252">
    <title>Let`s | Invoice</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");
        body{
            margin: 0;
            font-family: "Poppins", sans-serif;
            padding: 20px;
        }
    .top_rw{ background-color:#f4f4f4; }
    .td_w{ }
    button{ padding:5px 10px; font-size:14px;}
    .invoice-box {
        font-size: 14px;
        line-height: 24px;
        font-family: "Poppins", sans-serif;
        color: #555;
    }
    .invoice-box table {
//        max-width: 890px;
//        width: 100%;
//        line-height: inherit;
//        text-align: left;
//        margin: auto;
//        position: relative;
    }
    .invoice-box table td {
        padding: 5px 0;
        vertical-align:middle;

    }
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    .invoice-box table tr.information table td {
        padding-bottom: 9px;
        font-size: 14px;
    }

    .invoice-box table tr.information table td b{
        font-size: 20px;
        color: #363B45;
        display: inline-block;
        margin-bottom: 10px;
    }

    .invoice-box table tr.heading {
        background: linear-gradient(to right, #eb563e, #f27547);
    }
    .invoice-box table tr.heading td {
        border-bottom: none;
        font-weight: 600;
        font-size: 16px;
        color: #fff;
        padding: 10px;
    }
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
        padding: 15px 10px;
        font-size: 14px;
    }
    // .invoice-box table tr.item:nth-of-type(odd) {
    //     background: linear-gradient(to right, rgb(235 86 62 / 0.27), rgb(242 117 71 / 0.27));
    // }
    .invoice-box table tr.item:nth-of-type(even) {
        background: #fff;
    }
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    .my-app-store:hover .app-blk-btn {
        display: block !important;
    }
    .my-app-store:hover .app-wht-btn {
        display: none;
    }
    .app-store.btn.btn-primary.my-app-store {
        padding: 0 !important;
        border: 2px solid;
        margin-right: 20px;
        border-radius: 13px;
        background-color: #fff;
    }
    .btn-grp {
        display: table-row;
        margin-top: 20px;
    }
    .btn-grp img{
        width: 150px;
        border:1px solid #000;
        border-radius:13px;
    }
    .rtl {
        font-family: "Poppins", sans-serif;
        direction: rtl;
    }
    .rtl table {
        text-align: right;
    }
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
    </style>
</head>
<body>
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr>
                <td><img src="' . base_url('logo.png') . '" alt="logo" /></td>
            </tr>
            <tr>
                <td><img height="46px" src="' . base_url('invoice-title.png') . '" alt="logo" width="100%" /></td>
            </tr>
            <tr class="information">
                <td colspan="3">
                    <table style="width: 100%">
                    <tr><td colspan="2" style="padding-bottom: 5px;">
                <b> Invoice to:</b> <br></td><tr>
                        <tr>
                            <td colspan="2">
                                ' . $job_data['username'] . '<br>
                                ' . $job_data['address'] . '<br>
                                ' . $job_data['postal_code'] . '<br>
                                ' . $job_data['unit_number'] . '<br>
                            </td>
                            <td>
                            <div style="display:flex;align-items:center;justify-content: flex-end;"><span style="padding-right: 20px;display:inline-flex; text-align:left">Invoice#<br>Date</span><span style="display:inline-flex; text-align:left">' . $job_data['invoice_code'] . '<br>' . $job_data['date'] . '<br></span></div><br>

                                // <td style="width: 10%;"><br>
                                //     Date
                                // </td>
                                // <td style="text-align: left;color: #647680;font-weight: 500;font-size: 16px;line-height: 30px; padding-left: 15px">' . $job_data['invoice_code'] . '<br>
                                //     ' . $job_data['date'] . '
                                // </td>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
            <td colspan="3">
                <table class="table-striped" cellspacing="0px" cellpadding="2px" style="border:1px solid #f17046;width:100%;margin-bottom: 20px;" >
                <tr class="heading">
                    <td style="width:10%; text-align:center;border-top:1px solid #f17046;">
                        NO.
                    </td>
                    <td style="width:50%;text-align:left;border-top:1px solid #f17046;">
                        Item Description
                    </td>
                    <td style="width:10%;text-align:left;border-top:1px solid #f17046;">
                        Price
                    </td>
                </tr>
                <tr class="item">
                    <td style="width:10%; text-align:center;border-top:1px solid #f17046;">
                        1
                    </td>
                    <td style="width:50%;text-align:left;border-top:1px solid #f17046;">
                        ' . $job_data['item'] . '
                    </td>
                    <td style="width:10%; text-align:left;border-top:1px solid #f17046;">
                        $' . $job_data['price'] . '
                    </td>
                </tr>
                <tr class="item">
                    <td style="width:10%; text-align:center;border-top:1px solid #f17046;">
                        2
                    </td>
                    <td style="width:50%;text-align:left;border-top:1px solid #f17046;">
                    Fee Charges
                    </td>
                    <td style="width:10%; text-align:left;border-top:1px solid #f17046;">
                        $' . $job_data['charge'] . '
                    </td>
                </tr>
                <tr class="item">
                    <td style="width:10%; text-align:center;border-top:1px solid #f17046;">
                        1
                    </td>
                    <td style="width:50%;text-align:left;border-top:1px solid #f17046;">
                        Total
                    </td>
                    <td style="width:10%; text-align:left;border-top:1px solid #f17046;">
                        $' . $job_data['total'] . '
                    </td>
                </tr>
                            
            </table>
            </td>
            </tr>
           

</table>
</td>
</tr>
<tr>
               <td>
                 <table cellspacing="0px" cellpadding="2px">
                    <tr>
                    
                        <td style="color:#000;font-size: 14px;">
                        <b style="color: #363B45;font-size: 18px;margin-bottom: 5px;display: inline-block;">Payment Info :</b><br>
                        <b style="margin-bottom: 10px; display: inline-block"> Fastest, affordable way to get your problem 
                            solved. At Let`s, we strive to provide a reliable 
                            and satisfactory tech-enabled marketplace 
                            platform to our users by connecting communities 
                            with gigs. As such, our fees are very reasonable.</b>
                            <div class="btn-grp">
                                    <img class="app-wht-btn" style="margin-right: 20px" src="' . base_url('ios-app-btn.png') . '" alt="Apple" />
                                    <img class="app-wht-btn" src="' . base_url('android-app-btn.png') . '" alt="Play store" />
                                    
                            </div>
                        </td>
                        
                    </tr>
                 </table>
               </td>
               
            </tr>
        </table>
        </tr>
        <tr>
        <span style="height: 5px; width: 100%; background: #f17046; display: inline-block"></span>
        </tr>
        <table cellpadding="0" cellspacing="0">
            <tr>
                <td>@Copyright letsgroup.asia</td>
            </tr>
        </table>
    </div>
</body>
</html>';
        $this->m_pdf->pdf->WriteHTML($html);
        $filepath = SITE_UPD . 'invoice-' . time() . '.pdf';
        $this->m_pdf->pdf->Output(FCPATH . $filepath, 'F');
        return base_url($filepath);
//        echo $html;
    }

    public function add_user_chat($to_user_id = 0, $msg = "", $from_id = 0, $type = "message", $job_id = "0", $job_seeker_id = 0)
    {
        $result = array();
        $q = $this->db->query('SELECT iThreadId FROM tbl_threads WHERE(iUserId = ? OR iFriendId = ?) AND (iUserId = ? OR iFriendId = ?) AND job =?', array($from_id, $from_id, $to_user_id, $to_user_id, $job_id));
        if ($q->num_rows() === 1) {
            $result = $q->row_array();
            $id = $result['iThreadId'];
            $this->db->update('tbl_threads', array('eUserStatus' => 'y', 'eFriendStatus' => 'y'), array('iThreadId' => $id));
        } else {
            $this->db->insert('tbl_threads', array('iUserId' => $from_id, 'job' => $job_id, 'iFriendId' => $to_user_id, 'eIsactive' => 'y', 'job_seeker_id' => $job_seeker_id, 'dCreatedDate' => date('Y - m - d H:i:s')));
            $id = $this->db->insert_id();
        }
        if ($id > 0) {
            $message_in = array('iThreadId' => $id,
                'iSenderId' => $from_id,
                'iReceiverId' => $to_user_id,
                'type' => $type,
                'dCreatedDate' => get_date());
            if ($type == "message") {
                $message_in['vMessage'] = $msg;
            } else {
                if (isset($_FILES['attachment']) && !empty($_FILES['attachment']['name'])) {
                    $this->load->library('upload');
                    $this->load->library('image_lib');
                    $file_config = array();
                    if ($type == 'attachment') {
                        $path = FCPATH . SITE_UPD . 'attachment';
                    } else {
                        $path = FCPATH . SITE_UPD . 'chat';
                    }
                    if (!file_exists($path)) {
                        @mkdir($path);
                    }
                    $file_config['upload_path'] = $path;
                    $file_config['allowed_types'] = '*';
                    $file_config['overwrite'] = TRUE;
                    $file_config['max_size'] = '204800';
                    $file_config['file_name'] = md5(time() . rand());
                    $this->upload->initialize($file_config);
                    if ($this->upload->do_upload('attachment')) {
                        $content['status'] = 200;
                        $upload_data = $this->upload->data();
                        $message_in['vMessage'] = $upload_data['file_name'];
                    } else {
                        $message_in['vMessage'] = '';
                    }
                } else {
                    $message_in['vMessage'] = '';
                }
            }
            $r = $this->common->insert_data('tbl_messages', $message_in);
            $chat_g_data = $this->db->where('iMessageId', $r)->get('tbl_messages')->row();
            $r = $chat_g_data->iThreadId;
            if ($r > 0) {
                $q = $this->db->query('SELECT * FROM tbl_threads WHERE iThreadId = ?', $r);
                if ($q->num_rows() === 1) {
                    $result = $q->row_array();
                    $result['vMessage'] = $msg;
                }
            }

            if ($chat_g_data->type == "voice" || $chat_g_data->type == 'image') {
                $chat_g_data->vMessage = $this->common->get_full_path($chat_g_data->vMessage);
            } elseif ($chat_g_data->type == 'attachment') {
                $chat_g_data->vMessage = $this->common->get_full_path($chat_g_data->vMessage, 'attachment');
            }
            $result['last_message'] = $chat_g_data;
        }
        return $result;
    }

    public function send_push_chat($iThreadId = 0, $user_id = 0, $to_user_id = 0, $push_msg = "", $type = "message", $content = array())
    {
        $to_user_data = $this->common->get_data_by_id('tbl_users', 'id', $to_user_id, 'id', array('chat' => 1), '', 'ASC', '', 'row');
        if (!empty($to_user_data) && !empty($iThreadId)) {

            $sender_data = $this->common->get_data_by_id('tbl_users', 'id', $user_id, 'id,name', array(), '', 'ASC', '', 'row');
            $_Data = array();
            $_Data["iThreadId"] = $iThreadId;
            $_Data["iToUserId"] = $user_id;
            $_Data['push_type'] = '2'; //chat messages
            $_Data['sound'] = 'defualt';
            $_Data['badge'] = '1';
            if (empty($push_msg)) {
                if ($type == "message") {

                    $_Data['push_from'] = $content['last_message']->vMessage;
                    $_Data['image'] = "";
                } else if ($type == "image") {
                    $_Data['push_from'] = ucwords(strtolower($sender_data['name'])) . " sent you an image";
                    $_Data['image'] = $content['last_message']->vMessage;
                } else {
                    $_Data['push_from'] = ucwords(strtolower($sender_data['name'])) . " sent you new message";
                    $_Data['image'] = "";
                }
            } else {
                $_Data['push_from'] = str_replace('{{NAME}}', $sender_data['name'], $push_msg);
                $_Data['image'] = "";
            }
            $_Data['name'] = $sender_data['name'];
            $message['iToUserId'] = $_Data['iToUserId'];
            $message['name'] = $sender_data['name'];

            $data = $this->getUsersTokens($to_user_id);
            if (!empty($data['tokens'])) {
                if ($data['tokens'][0]['eDeviceType'] == "iOS") {
                    if (empty($push_msg)) {
                        $_Data['body'] = ucwords(strtolower($sender_data['name'])) . " sent you new message";
                    } else {
                        $_Data['body'] = str_replace('{{NAME}}', $sender_data['name'], $push_msg);
                    }
                    $_Data['message'] = $message;
                    $badge = $this->updateBadge($data['tokens'][0]['iDeviceId']);
                    $fields = array(
                        'to' => $data['tokens'][0]['vPushToken'],
                        'notification' => $_Data,
                        'data' => $_Data,
                        'priority' => 'high'
                    );
                    $fields = json_encode($fields);
                } else {
                    $badge = $this->updateBadge($data['tokens'][0]['iDeviceId']);
                    $fields = array(
                        'to' => $data['tokens'][0]['vPushToken'],
                        'data' => $_Data,
                        'priority' => 'high'
                    );
                    $fields = json_encode($fields);
                }
                sendPushNotification($fields);
            }
        }
    }

    function getUsersTokens($user_ids = array())
    {
        $response['tokens'] = $this->db->select('d.iDeviceId,d.vPushToken,d.eDeviceType')
            ->from('tbl_user_devices as d')->where('vPushToken!=', '')
            ->where_in('d.iUserId', $user_ids)
            ->get()->result_array();
        return $response;
    }

    function updateBadge($iDeviceId = 0)
    {
        $badge = 1;
        $r = $this->db->get_where('tbl_user_devices', array('iDeviceId' => $iDeviceId))->row_array();
        if (count($r) > 0) {
            $badge = $r['iBadge'] + 1;
            $this->db->update('tbl_user_devices', array('iBadge' => $badge), array('iDeviceId' => $iDeviceId));
        }
        return $badge;
    }

    public function add_bank_Account($user_id = 0, $post = array())
    {
        $content = array('status' => 412, 'message' => $this->lang->line('err_something_went_wrong'), 'data' => new stdClass());
        $get_user_data = $this->common->get_data_by_id('tbl_users', 'id', $user_id, '*', array(), '', 'ASC', '', 'row');
        if (!empty($get_user_data)) {
            $check = $this->stripe->createConnectUser($get_user_data['email'], $post, get_dob($post['dob']));
            if ($check['status'] == 200) {
                $data_insert = array(
                    'user_id' => $user_id,
                    'stripe_id' => $check['id'],
                    'first_name' => $post['first_name'],
                    'last_name' => $post['last_name'],
                    'dob' => date('y-m-d', strtotime($post['dob'])),
                    'address_line' => $post['address_line'],
                    'postal_code' => $post['postal_code'],
                    'unit_number' => $post['unit_number'],
                    'city' => $post['city'],
                    'state' => $post['state'],
                    'country' => $post['country'],
                    'transit_number' => $post['transit_number'],
                    'account_number' => $post['account_number'],
                    'mobile_number' => $post['mobile_number'],
                    'id_number' => $post['id_number'],
                    'created' => get_date(),
                    'updated' => get_date(),
                );
                $last_id = $this->common->insert_data('tbl_user_bank', $data_insert);
                $content['status'] = 200;
                $content['message'] = $this->lang->line('succ_bank_added');
                $content['data'] = $this->common->get_data_by_id('tbl_user_bank', 'id', $last_id, '*', array(), '', 'ASC', '', 'row');;
            } else {
                $content['status'] = $check['status'];
                $content['message'] = $check['message'];
                // $content = $check;
            }
        }
        return $content;
    }

}
