<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Job extends Ws_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->lang->load('users', $this->data['language']);
        parent::load_version_model('ws/User_model_' . $this->data['version'], 'user_model');
        $this->load->model('ws/Job_model', 'Main');
    }

    public function index()
    {
        echo json_encode($this->input->post());
    }

    public function get_city_and_category()
    {
        $data = new stdClass();
        $extra = array('client_fee' => CLIENT_FEE);
        $data->category = $this->Main->get_category();
        $data->city = $this->Main->get_city();
        je_mobile(200, $this->lang->line('succ'), $data, $extra);
    }

    public function get_category()
    {
        $extra = array('client_fee' => CLIENT_FEE);
        $data = $this->Main->get_category();
        je_mobile(200, $this->lang->line('succ'), $data, $extra);
    }

    public function get_sub_category()
    {
        $data = array();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $this->form_validation->set_rules('category_id', 'Category ID', 'required');
            if ($this->form_validation->run() == FALSE) {
                $this->data['content']['status'] = 412;
                $this->data['content']['message'] = $this->form_validation->error_array();
                $i = 0;
                foreach ($this->form_validation->error_array() as $key => $value) {
                    if ($i != 0) {
                        continue;
                    }
                    $this->data['content']['message'] = $value;
                    $i++;
                }
            } else {
                $_POST['user_id'] = $exists->iUserId;
                $data = $this->Main->getSubCategory($this->input->post());
                $this->data['content']['status'] = 200;
                $this->data['content']['message'] = $this->lang->language['succ'];
            }

        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function get_city()
    {
        $data = $this->Main->get_city();
        je_mobile(200, $this->lang->line('succ'), $data);
    }

    public function create_job()
    {
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            // echo json_encode($this->input->post());
            // die();
            $rules = $this->create_job_rules();
            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() == FALSE) {
                $this->data['content']['status'] = 412;
                $this->data['content']['message'] = get_error($this->form_validation->error_array());
            } else {
                $user_id = $exists->iUserId;
                $in_data = $this->Main->get_insert_array($rules, $user_id);
                $this->common->insert_data('tbl_job', $in_data);
                $this->data['content']['status'] = 200;
                $this->data['content']['message'] = $this->lang->language['succ_job_created'];
            }
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function create_job_rules()
    {
        $type = strtolower($this->input->post('type'));
        $rules = array(
            array(
                'field' => 'category_id',
                'label' => 'category_id',
                'rules' => 'trim|required',
            ),
            array(
                'field' => 'sub_category_id',
                'label' => 'Sub Category',
                'rules' => 'trim|required',
            ),
            array(
                'field' => 'type',
                'label' => 'type',
                'rules' => 'trim|required',
            ),
            array(
                'field' => 'offer',
                'label' => 'offer',
                'rules' => 'trim|required',
            ),
            array(
                'field' => 'skills',
                'label' => 'skills',
                'rules' => 'trim',
            ),
        );
        if ($type == "delivery") {
            $rules[] = array(
                'field' => 'description',
                'label' => 'description',
                // 'rules' => 'trim|required',
                'rules' => 'trim',
            );
            $rules[] = array(
                'field' => 'task_date',
                'label' => 'task_date',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'task_time',
                'label' => 'task_time',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_location',
                'label' => 'start_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_latitude',
                'label' => 'start_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_longitude',
                'label' => 'start_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_location',
                'label' => 'end_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_latitude',
                'label' => 'end_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_longitude',
                'label' => 'end_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_country',
                'label' => 'start_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_country',
                'label' => 'end_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_city',
                'label' => 'start_city',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_city',
                'label' => 'end_city',
                'rules' => 'trim|required',
            );
            // $rules[] = array(
            //     'field' => 'receiver_name',
            //     'label' => 'receiver_name',
            //     'rules' => 'trim|required',
            // );
            // $rules[] = array(
            //     'field' => 'receiver_number',
            //     'label' => 'receiver_number',
            //     'rules' => 'trim|required',
            // );
        } elseif ($type == "move") {
            $rules[] = array(
                'field' => 'task_date',
                'label' => 'task_date',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'task_time',
                'label' => 'task_time',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'description',
                'label' => 'description',
                'rules' => 'trim',
                // 'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_location',
                'label' => 'start_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_latitude',
                'label' => 'start_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_longitude',
                'label' => 'start_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_location',
                'label' => 'end_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_latitude',
                'label' => 'end_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_longitude',
                'label' => 'end_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_country',
                'label' => 'start_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_country',
                'label' => 'end_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_city',
                'label' => 'start_city',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_city',
                'label' => 'end_city',
                'rules' => 'trim|required',
            );
        } elseif ($type == 'fix') {
            $rules[] = array(
                'field' => 'start_location',
                'label' => 'start_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_latitude',
                'label' => 'start_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_longitude',
                'label' => 'start_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'description',
                'label' => 'description',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'task_date',
                'label' => 'task_date',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'task_time',
                'label' => 'task_time',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_country',
                'label' => 'start_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_city',
                'label' => 'start_city',
                'rules' => 'trim|required',
            );
        } elseif ($type == 'hitch') {
            $rules[] = array(
                'field' => 'task_date',
                'label' => 'task_date',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'task_time',
                'label' => 'task_time',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_location',
                'label' => 'start_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_latitude',
                'label' => 'start_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_longitude',
                'label' => 'start_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_location',
                'label' => 'end_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_latitude',
                'label' => 'end_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_longitude',
                'label' => 'end_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'passengers',
                'label' => 'passengers',
                'rules' => 'trim',
            );
            $rules[] = array(
                'field' => 'start_country',
                'label' => 'start_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_country',
                'label' => 'end_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_city',
                'label' => 'start_city',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'end_city',
                'label' => 'end_city',
                'rules' => 'trim|required',
            );
        } else {
            $rules[] = array(
                'field' => 'start_location',
                'label' => 'start_location',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_latitude',
                'label' => 'start_latitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_longitude',
                'label' => 'start_longitude',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'description',
                'label' => 'description',
                'rules' => 'trim|required',
            );
            // $rules[] = array(
            //     'field' => 'qualification',
            //     'label' => 'qualification',
            //     'rules' => 'trim|required',
            // );
            $rules[] = array(
                'field' => 'start_country',
                'label' => 'start_country',
                'rules' => 'trim|required',
            );
            $rules[] = array(
                'field' => 'start_city',
                'label' => 'start_city',
                'rules' => 'trim|required',
            );
        }
        return $rules;
    }

    public function fav_job()
    {
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $user_id = $exists->iUserId;
            $job_id = $this->input->post('job_id');
            $get_job = $this->common->get_data_by_id('tbl_job', 'id', $job_id, 'id', array('user_id!=' => $user_id), '', 'ASC', '', 'row');
            if (!empty($get_job)) {
                $fav = $this->common->get_data_by_id('tbl_job_fav', 'job_id', $job_id, 'id', array('user_id' => $user_id), '', 'ASC', '', 'row');
                if (!empty($fav)) {
                    $this->common->delete_data('tbl_job_fav', array('job_id' => $job_id, 'user_id' => $user_id));
                    $this->data['content']['message'] = $this->lang->language['succ_job_fav_removed'];
                } else {
                    $this->common->insert_data('tbl_job_fav', array('user_id' => $user_id, 'job_id' => $job_id));
                    $this->data['content']['message'] = $this->lang->language['succ_job_fav_added'];
                }
                $this->data['content']['status'] = 200;
            } else {
                $this->data['content']['status'] = 412;
                $this->data['content']['message'] = $this->lang->language['err_job_not_found'];
            }
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function ignore_job()
    {
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $user_id = $exists->iUserId;
            $job_id = $this->input->post('job_id');
            $get_job = $this->common->get_data_by_id('tbl_job', 'id', $job_id, 'id', array('user_id!=' => $user_id), '', 'ASC', '', 'row');
            if (!empty($get_job)) {
                $fav = $this->common->get_data_by_id('tbl_job_ignore', 'job_id', $job_id, 'id', array('user_id' => $user_id), '', 'ASC', '', 'row');
                if (!empty($fav)) {
                    $this->common->delete_data('tbl_job_ignore', array('job_id' => $job_id, 'user_id' => $user_id));
                    $this->data['content']['message'] = $this->lang->language['succ_job_ignore_remove'];
                } else {
                    $this->common->insert_data('tbl_job_ignore', array('user_id' => $user_id, 'job_id' => $job_id));
                    $this->data['content']['message'] = $this->lang->language['succ_job_ignore_add'];
                }
                $this->data['content']['status'] = 200;
            } else {
                $this->data['content']['status'] = 412;
                $this->data['content']['message'] = $this->lang->language['err_job_not_found'];
            }
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function job_listing()
    {
        $data = array();
        $count = array('count' => '0');
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $user_id = $exists->iUserId;
            $data = $this->Main->job_listing($user_id);
            $count['count'] = $this->Main->job_listing_count($user_id);
            $this->data['content']['status'] = 200;
            $this->data['content']['message'] = $this->lang->language['succ'];
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data, $count);
    }

    public function apply_job()
    {
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $this->form_validation->set_rules($this->apply_job_rules());
            if ($this->form_validation->run() == FALSE) {
                $this->data['content']['status'] = 412;
                $this->data['content']['message'] = get_error($this->form_validation->error_array());
            } else {
                $user_id = $exists->iUserId;
                $this->data['content'] = $this->Main->apply_job($user_id);
            }
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    private function apply_job_rules()
    {
        $rules = array(
            array(
                'field' => 'job_id',
                'label' => 'job_id',
                'rules' => 'trim|required',
            ),
            array(
                'field' => 'offer',
                'label' => 'offer',
                'rules' => 'trim|required',
            ),
            array(
                'field' => 'proposal',
                'label' => 'proposal',
                'rules' => 'trim|required',
            ),
        );
        return $rules;
    }

    public function get_favourite_list()
    {
        $data = array();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $user_id = $exists->iUserId;
            $data = $this->Main->get_favourite_list($user_id);
            $this->data['content']['status'] = 200;
            $this->data['content']['message'] = $this->lang->language['succ'];
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function get_applied_job_list()
    {
        $data = array();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $user_id = $exists->iUserId;
            $data = $this->Main->get_applied_job_list($user_id);
            $this->data['content']['status'] = 200;
            $this->data['content']['message'] = $this->lang->language['succ'];
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function get_single_job()
    {
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (count($exists)) {
            $user_id = $exists->iUserId;
            $where = array(
                'j.id' => $this->input->post('job_id'),
                'u.status' => 'active'
            );
            $data = $this->db->select("u.name,u.profile_image,j.*,
        (SELECT COUNT(tbl_job_fav.id) FROM tbl_job_fav WHERE tbl_job_fav.user_id=$user_id AND tbl_job_fav.job_id=j.id) as favourite,
        (SELECT COUNT(tbl_job_ignore.id) FROM tbl_job_ignore WHERE tbl_job_ignore.user_id=$user_id AND tbl_job_ignore.job_id=j.id) as job_ignore,
        (SELECT COUNT(tbl_job_apply.id) FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id AND tbl_job_apply.job_id=j.id) as apply,
        (SELECT tbl_job_apply.is_prev_rejected FROM tbl_job_apply WHERE tbl_job_apply.user_id=$user_id AND tbl_job_apply.job_id=j.id) as is_prev_rejected,
        (SELECT tbl_threads.iThreadId FROM tbl_threads WHERE tbl_threads.job=j.id AND ((tbl_threads.iUserId=$user_id AND tbl_threads.iFriendId=j.user_id) OR (tbl_threads.iUserId=j.user_id AND tbl_threads.iFriendId=$user_id))) as thread_id,"
            )->from('tbl_job j')->join('tbl_users u', 'u.id=j.user_id')->where($where)->get()->row_array();
            if (!empty($data)) {
                $data['thread_id'] = (is_null($data['thread_id'])) ? '0' : $data['thread_id'];
                $data['is_prev_rejected'] = (is_null($data['is_prev_rejected'])) ? '0' : $data['is_prev_rejected'];
                $data['profile_image'] = checkImage(1, $data['profile_image'], 0, 0, false);
                $this->data['content']['status'] = 200;
                $this->data['content']['message'] = $this->lang->language['succ'];
            } else {
                $this->data['content']['status'] = 412;
                $this->data['content']['message'] = $this->lang->language['err_job_not_found'];
            }
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function get_completed_job()
    {
        $data = array();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (!empty($exists)) {
            $user_id = $exists->iUserId;
            $data = $this->Main->get_completed_job($user_id);
            $this->data['content']['status'] = 200;
            $this->data['content']['message'] = $this->lang->language['succ'];
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }

    public function delete_job()
    {
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (!empty($exists)) {
            $user_id = $exists->iUserId;
            $this->data['content'] = $this->Main->remove_job($user_id);
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }
    public function applied_list(){
        $data = new stdClass();
        $vAuthToken = parent::getAuthToken();
        $exists = $this->user_model->check_login($vAuthToken);
        if (empty($exists)) {
            $limit = $this->input->post('job_id');
            $data = $this->Main->applied_list($limit);
            $this->data['content']['status'] = 200;
            $this->data['content']['message'] = $this->lang->language['succ'];
        } else {
            $this->data['content']['status'] = 401;
            $this->data['content']['message'] = $this->lang->language['err_please_login'];
        }
        je_mobile($this->data['content']['status'], $this->data['content']['message'], $data);
    }
}